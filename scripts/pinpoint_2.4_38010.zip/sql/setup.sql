-- run this script as a user with DBA privileges
-- it will create the c$pinpoint user and then use that
-- account for the rest of the process
-- 
-- you must have previously copied the dll to correct
-- location and changed the library definition in
-- create_pinpoint_library.sql

@create_pinpoint_user

connect c$pinpoint/pinpoint

-- edit the definition in here to point at the dll/so

@create_pinpoint_library

@create_license

@create_pinpoint

quit;
