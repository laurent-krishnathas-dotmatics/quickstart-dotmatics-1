create or replace library astex as
'C:\oraclexe\app\oracle\product\10.2.0\server\BIN\acc_cartridge.dll';

/

show errors;

quit;
