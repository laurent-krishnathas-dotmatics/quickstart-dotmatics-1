-- Implementation of chemistry searching cartridge and associated functions

set echo off

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_mol2smi_clob(smiles IN CLOB)
		return varchar2 deterministic is external
           	NAME "acc_mol2smi"
           	LIBRARY dotmatics_lib
		with context
           	PARAMETERS (CONTEXT,
                 smiles  OCILOBLOCATOR,
                 smiles  INDICATOR short,
                 return INDICATOR short,
               	return LENGTH short);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_mol2smi(smiles IN BLOB)
		return varchar2 deterministic is external
           	NAME "acc_mol2smi"
           	LIBRARY dotmatics_lib
		with context
           	PARAMETERS (CONTEXT,
                 smiles  OCILOBLOCATOR,
                 smiles  INDICATOR short,
                 return INDICATOR short,
               	return LENGTH short);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_calc_mw(smiles IN varchar2)
		return float is external
           	NAME "acc_calc_mw"
           	LIBRARY dotmatics_lib
           	PARAMETERS (smiles string,
           	   	smiles  INDICATOR short);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_inchi2mw(smiles IN varchar2)
		return float is external
           	NAME "acc_inchi2mw"
           	LIBRARY dotmatics_lib
           	PARAMETERS (smiles string,
           	    smiles  INDICATOR short);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_compare(fp1 IN varchar2, fp2 IN varchar2, method IN varchar2)
		return float is external
           	NAME "acc_compare"
           	LIBRARY dotmatics_lib
           	PARAMETERS (fp1 string, fp2 string, method string);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_pipe_talk(s IN varchar2)
		return varchar2 deterministic is external
           	NAME "acc_pipe_talk"
           	LIBRARY dotmatics_lib
           	PARAMETERS (s string);
/
show errors

create or replace FUNCTION acc_formula2mw(smiles IN varchar2)
		return float is external
           	NAME "acc_formula2mw"
           	LIBRARY dotmatics_lib
           	PARAMETERS (smiles string,
           	    smiles  INDICATOR short);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_calc_hac(smiles IN varchar2)
		return binary_integer is external
           	NAME "acc_calc_hac"
           	LIBRARY dotmatics_lib
           	PARAMETERS (smiles string,
           	    smiles  INDICATOR short);
/
show errors

create or replace function acc_contains2(a varchar2, b varchar2) return binary_integer as
   EXTERNAL
   LANGUAGE C
   NAME "acc_contains2"
   LIBRARY dotmatics_lib
   PARAMETERS(a string, b string);
/
show errors

create or replace function acc_containsf(a varchar2, b varchar2) return number as
   EXTERNAL
   LANGUAGE C
   NAME "acc_contains"
   LIBRARY dotmatics_lib
   WITH CONTEXT
   PARAMETERS(CONTEXT, a string, a indicator, b string, b indicator);
/
show errors

create or replace function acc_exactf(a varchar2, b varchar2) return number as
   EXTERNAL
   LANGUAGE C
   NAME "acc_exact"
   LIBRARY dotmatics_lib
   WITH CONTEXT
   PARAMETERS(CONTEXT, a string, a indicator, b string, b indicator);
/
show errors

create or replace function acc_graphf(a varchar2, b varchar2) return number as
   EXTERNAL
   LANGUAGE C
   NAME "acc_graph"
   LIBRARY dotmatics_lib
   WITH CONTEXT
   PARAMETERS(CONTEXT, a string, a indicator, b string, b indicator);
/
show errors

create function acc_simf(a varchar2, b varchar2) return number as
   EXTERNAL
   LANGUAGE C
   NAME "acc_sim"
   LIBRARY dotmatics_lib
   WITH CONTEXT
   PARAMETERS(CONTEXT, a string, a indicator, b string, b indicator);
/
show errors

create or replace function acc_tautomerf(a varchar2, b varchar2) return number as
   EXTERNAL
   LANGUAGE C
   NAME "acc_tautomer"
   LIBRARY dotmatics_lib
   WITH CONTEXT
   PARAMETERS(CONTEXT, a string, a indicator, b string, b indicator);
/
show errors

create function acc_fpf(a varchar2, b varchar2) return number as
begin
  if a > b then
    return 1;
  else
    return 0;
  end if;
end;
/
show errors


-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_cansmi(s IN varchar2)
		return varchar2 deterministic is external
           	NAME "acc_cansmi"
           	LIBRARY dotmatics_lib
           	WITH CONTEXT
   			PARAMETERS(CONTEXT, s string,
   			    s  INDICATOR short,
   			    return INDICATOR short,
               	return LENGTH short);
/
show errors


-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_cansmi_noniso(s IN varchar2)
		return varchar2 deterministic is external
           	NAME "acc_cansmi_noniso"
           	LIBRARY dotmatics_lib
           	WITH CONTEXT
   			PARAMETERS(CONTEXT, s string,
   			    s  INDICATOR short,
   			    return INDICATOR short,
               	return LENGTH short);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_get_version
		return varchar2 deterministic is external
           	NAME "acc_get_version"
           	LIBRARY dotmatics_lib;
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace PROCEDURE acc_set_log_level(level IN binary_integer)
		is external
           	NAME "acc_set_log_level"
           	LIBRARY dotmatics_lib
           	PARAMETERS (level int);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_calc_mw_exact(smiles IN varchar2)
        return float is external
            NAME "acc_calc_mw_exact"
            LIBRARY dotmatics_lib
            PARAMETERS (smiles string,
                smiles  INDICATOR short);
/
show errors

-- CREATE BTREE OPERATORS

create operator acc_contains binding (varchar2, varchar2) return number using acc_containsf;

create operator acc_exact binding (varchar2, varchar2) return number using acc_exactf;

create operator acc_fp binding (varchar2, varchar2) return number using acc_fpf;

create operator acc_sim binding (varchar2, varchar2) return number using acc_simf;

create operator acc_graph binding (varchar2, varchar2) return number using acc_graphf;

create operator acc_tautomer binding (varchar2, varchar2) return number using acc_tautomerf;


-- CREATE INDEXTYPE IMPLEMENTATION TYPE
create type chm_im authid current_user as object
(
  scanctx RAW(4),
  static function ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList)
  return NUMBER,
  static function ODCIIndexCreate (ia sys.odciindexinfo, parms varchar2)
  return number,
  static function ODCIIndexDrop(ia sys.odciindexinfo) return number,
  STATIC FUNCTION odciindexinsert(ia sys.odciindexinfo, rid VARCHAR2,
                                                    newval VARCHAR2)
                                  RETURN NUMBER,
  STATIC FUNCTION odciindexdelete(ia sys.odciindexinfo, rid VARCHAR2,
                                                    oldval VARCHAR2)
                                  RETURN NUMBER,
  STATIC FUNCTION odciindexupdate(ia sys.odciindexinfo, rid VARCHAR2,
                                  oldval VARCHAR2, newval VARCHAR2)
                                  RETURN NUMBER,
  static function ODCIIndexStart(sctx IN OUT chm_im, ia sys.odciindexinfo,
                         op sys.odciPredInfo, qi sys.ODCIQueryInfo,
                         strt number, stop number,
                         cmpval varchar2) return number,
  member function ODCIIndexFetch(nrows number, rids OUT sys.odciridlist)
      return number,
  member function ODCIIndexClose return number
);
/
show errors


---------------------------------
--  CREATE IMPLEMENTATION UNIT --
---------------------------------

-- CREATE TYPE BODY
create or replace type body chm_im
is
   static function ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList)
       return number is
   begin
       ifclist := sys.ODCIObjectList(sys.ODCIObject('SYS','ODCIINDEX1'));
       return ODCIConst.Success;
   end ODCIGetInterfaces;

--  static function ODCIIndexCreate (ia sys.odciindexinfo, parms varchar2)
--   return number
--  is
--   i integer;
--   stmt varchar2(1000);
--   cnum integer;
--   junk integer;
--  begin
--   -- construct the sql statement
--     stmt := 'create table ' || ia.IndexSchema || '.' ||
--       ia.IndexName || '_chm'  ||
--       '( f1 , f2 ) as select ' ||
--       ia.IndexCols(1).ColName || ', ROWID from ' ||
--      ia.IndexCols(1).TableSchema || '.' || ia.IndexCols(1).TableName;
--
--   dbms_output.put_line('CREATE');
--   dbms_output.put_line(stmt);
--
--   -- execute the statement
--   cnum := dbms_sql.open_cursor;
--   dbms_sql.parse(cnum, stmt, dbms_sql.native);
--   junk := dbms_sql.execute(cnum);
--   dbms_sql.close_cursor(cnum);
--
--   return ODCIConst.Success;
--  end;

  static function ODCIIndexDrop(ia sys.odciindexinfo) return number is
   stmt varchar2(1000);
   cnum integer;
   junk integer;
  begin
    -- construct the sql statement
   stmt := 'drop table ' || ia.IndexSchema || '.' || ia.IndexName || '_chm';

   dbms_output.put_line('DROP');
   dbms_output.put_line(stmt);

   -- execute the statement
   cnum := dbms_sql.open_cursor;
   dbms_sql.parse(cnum, stmt, dbms_sql.native);
   junk := dbms_sql.execute(cnum);
   dbms_sql.close_cursor(cnum);

   return ODCIConst.Success;
  end;

  STATIC FUNCTION odciindexcreate(ia sys.odciindexinfo, parms VARCHAR2)
                                  RETURN NUMBER AS external
    name "qxiqtbz"
    library dotmatics_lib
    WITH context
    parameters (
    context,
    ia,
    ia indicator struct,
	parms,
	parms indicator,
    RETURN ocinumber
               );

  STATIC FUNCTION odciindexinsert(ia sys.odciindexinfo, rid VARCHAR2,
                                                    newval VARCHAR2)
                                  RETURN NUMBER AS external
    name "qxiqtbi"
    library dotmatics_lib
    WITH context
    parameters (
    context,
    ia,
    ia indicator struct,
    rid,
    rid indicator,
    newval,
    newval indicator,
    RETURN ocinumber
               );

  STATIC FUNCTION odciindexdelete(ia sys.odciindexinfo, rid VARCHAR2,
                                                    oldval VARCHAR2)
                                  RETURN NUMBER AS external
    name "qxiqtbd"
    library dotmatics_lib
    WITH context
    parameters (
    context,
    ia,
    ia indicator struct,
    rid,
    rid indicator,
    oldval,
    oldval indicator,
    RETURN ocinumber
               );

  STATIC FUNCTION odciindexupdate(ia sys.odciindexinfo, rid VARCHAR2,
                                  oldval VARCHAR2, newval VARCHAR2)
                                  RETURN NUMBER AS external
    name "qxiqtbu"
    library dotmatics_lib
    WITH context
    parameters (
    context,
    ia,
    ia indicator struct,
    rid,
    rid indicator,
    oldval,
    oldval indicator,
    newval,
    newval indicator,
    RETURN ocinumber
               );

  static function ODCIIndexStart(sctx in out chm_im, ia sys.odciindexinfo,
                         op sys.odciPredInfo,
                         qi sys.ODCIQueryInfo,
                         strt number,
                         stop number,
                         cmpval varchar2)
     return number as external
     name "qxiqtbs"
     library dotmatics_lib
     with context
     parameters (
       context,
       sctx,
       sctx INDICATOR STRUCT,
       ia,
       ia INDICATOR STRUCT,
       op,
       op INDICATOR STRUCT,
       qi,
       qi INDICATOR STRUCT,
       strt,
       strt INDICATOR,
       stop,
       stop INDICATOR,
       cmpval,
       cmpval INDICATOR,
       return OCINumber
    );

  member function ODCIIndexFetch(nrows number, rids OUT sys.odciridlist)
   return number as external
   name "qxiqtbf"
   library dotmatics_lib
   with context
   parameters (
     context,
     self,
     self INDICATOR STRUCT,
     nrows,
     nrows INDICATOR,
     rids,
     rids INDICATOR,
     return OCINumber
   );

  member function ODCIIndexClose return number as external
   name "qxiqtbc"
   library dotmatics_lib
   with context
   parameters (
     context,
     self,
     self INDICATOR STRUCT,
     return OCINumber
   );

end;
/
show errors

---------------------
-- CREATE INDEXTYPE
---------------------

create indextype chm
for
acc_contains(varchar2, varchar2),
acc_exact(varchar2, varchar2),
acc_fp(varchar2, varchar2),
acc_sim(varchar2, varchar2),
acc_graph(varchar2, varchar2),
acc_tautomer(varchar2, varchar2)
using chm_im;

---------------------
-- CREATE LICENSE TABLE
---------------------

create table options (
name varchar2(3000),
value varchar2(3000)
);

--------------------------
--    USAGE EXAMPLES    --
--------------------------
set serveroutput on size 20000

-----------------
-- CREATE INDEX
-----------------

-- this is necessary so that the license can be found
-- there should be a way to figure out what schema the indextype
-- is installed into, but I don't see how to do it right now

create public synonym pinpoint_options for options;

--set timing on;

create table test (
	smiles varchar2(4000),
	id integer
);

insert into test(smiles, id) values('c1ccccc1', 1);
insert into test(smiles, id) values('c1ncccc1', 2);
insert into test(smiles, id) values('c1ncccc1Cl', 3);
insert into test(smiles, id) values('c1ncccc1Br', 4);

create index test_idx on test(smiles) indextype is chm parameters('test');

select count(*) from test where acc_contains(smiles, 'Cl') = 1;

select count(*) from test where acc_contains(smiles, '[Cl,Br]') = 1;

select count(*) from test where acc_contains(smiles, 'c1ncccc1') = 1;

select fp0, fp1, fp2, fp3, fp4 from test_idx_chm;

--drop index test_idx;

--drop table test;

create role pinpoint;


grant execute on chm_im to public;
grant execute on chm_im to pinpoint;
grant execute on chm to public;
grant execute on chm to pinpoint;

grant execute on acc_exact to pinpoint;
grant execute on acc_exact to public;
grant execute on acc_contains to pinpoint;
grant execute on acc_contains to public;
grant execute on acc_fp to pinpoint;
grant execute on acc_fp to public;
grant execute on acc_sim to pinpoint;
grant execute on acc_sim to public;
grant execute on acc_tautomer to pinpoint;
grant execute on acc_tautomer to public;
grant execute on acc_graph to pinpoint;
grant execute on acc_graph to public;
grant execute on acc_set_log_level to pinpoint;
grant execute on acc_set_log_level to public;

grant select on options to public;
grant select on options to pinpoint;

grant execute on acc_mol2smi to pinpoint;
grant execute on acc_mol2smi to public;
grant execute on acc_cansmi to pinpoint;
grant execute on acc_cansmi to public;
grant execute on acc_cansmi_noniso to pinpoint;
grant execute on acc_cansmi_noniso to public;
grant execute on acc_mol2smi_clob to pinpoint;
grant execute on acc_mol2smi_clob to public;
grant execute on acc_calc_mw to pinpoint;
grant execute on acc_calc_mw to public;
grant execute on acc_calc_hac to pinpoint;
grant execute on acc_calc_hac to public;
grant execute on acc_get_version to pinpoint;
grant execute on acc_get_version to public;
grant execute on acc_calc_mw_exact to pinpoint;
grant execute on acc_calc_mw_exact to public;
grant execute on acc_inchi2mw to pinpoint;
grant execute on acc_inchi2mw to public;

create public synonym acc_contains for acc_contains;
create public synonym acc_fp for acc_fp;
create public synonym acc_exact for acc_exact;
create public synonym acc_sim for acc_sim;
create public synonym acc_tautomer for acc_tautomer;
create public synonym acc_graph for acc_graph;
create public synonym acc_mol2smi for acc_mol2smi;
create public synonym acc_mol2smi_clob for acc_mol2smi_clob;
create public synonym acc_calc_mw for acc_calc_mw;
create public synonym acc_calc_hac for acc_calc_hac;
create public synonym acc_cansmi for acc_cansmi;
create public synonym acc_cansmi_noniso for acc_cansmi_noniso;
create public synonym acc_get_version for acc_get_version;
create public synonym acc_set_log_level for acc_set_log_level;
create public synonym acc_calc_mw_exact for acc_calc_mw_exact;
create public synonym acc_inchi2mw for acc_inchi2mw;

--quit;
