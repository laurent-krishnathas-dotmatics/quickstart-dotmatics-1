-- list the indexes that depend on the pinpoint index type
-- will produce sql to drop/create all pinpoint indexes
-- the commands can be used to recreate all indexes e.g when the pinpoint library has been updated
-- NOTE: SQL will need editting when the passwords for a user with pinpoint sequences is not 
-- identical to the user names (apart from c$pinpoint/pinpoint)

set pagesize 0

select 
'connect '||owner||'/'||replace(owner,'C$')||';'||chr(10)||
'drop index '||i.index_name||' force;'||chr(10)||
'create index '||i.index_name||' on '||i.table_name||'('||c.column_name||') indextype is c$pinpoint.chm;'||chr(10)
from all_indexes i, all_ind_columns c 
where i.index_name = c.index_name and i.ITYP_OWNER = 'C$PINPOINT' and i.ITYP_NAME = 'CHM';

-- quit;