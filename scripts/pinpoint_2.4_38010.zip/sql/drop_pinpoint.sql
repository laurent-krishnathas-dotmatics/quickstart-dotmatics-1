drop table test;
drop index maybridge_smiles_idx;

drop public synonym acc_contains;
drop public synonym acc_fp;
drop public synonym acc_exact;
drop public synonym acc_graph;
drop public synonym acc_tautomer;
drop public synonym acc_sim;
drop public synonym acc_calc_mw;
drop public synonym acc_calc_hac;
drop public synonym acc_mol2smi;
drop public synonym acc_mol2smi_clob;
drop public synonym acc_cansmi;
drop public synonym acc_cansmi_noniso;
drop public synonym acc_get_version;
drop public synonym acc_set_log_level;
drop public synonym acc_calc_mw_exact;

drop public synonym pinpoint_options;

drop role pinpoint;

drop indextype chm;
drop type chm_im;
drop operator acc_contains;
drop operator acc_exact;
drop operator acc_fp;
drop operator acc_sim;
drop operator acc_graph;
drop operator acc_tautomer;
drop function acc_containsf;
drop function acc_exactf;
drop function acc_fpf;
drop function acc_simf;
drop function acc_graphf;
drop function acc_tautomerf;
drop function acc_calc_hac;
drop function acc_calc_mw;
drop function acc_mol2smi;
drop function acc_mol2smi_clob;
drop function acc_cansmi;
drop function acc_cansmi_noniso;
drop function acc_get_version;
drop procedure acc_set_log_level;

quit;

