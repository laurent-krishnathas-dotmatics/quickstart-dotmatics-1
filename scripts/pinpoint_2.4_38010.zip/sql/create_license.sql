create table options (
  name varchar2(1000),
  value varchar2(1000)
);

insert into options(name, value) values('license',
'f3bdb68709124bb199f54971abf3a7dbe46dc413d1c7ae71');

--quit;
