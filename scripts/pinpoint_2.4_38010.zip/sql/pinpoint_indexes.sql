-- list the indexes that depend on the pinpoint index type
-- will produce a list of indexes and the underlying tables
-- the commands can be used to purge all the indexes in
-- the users schema: handy for tidying up before removing pinpoint
-- best run with
--   sqlplus -S user/password @pinpoint_indexes

set pagesize 0

SELECT 'drop index ' || index_name || ' force;'
  FROM ind
 WHERE index_type = 'DOMAIN' AND ityp_name = 'CHM';

SELECT 'drop table ' || index_name || '_CHM;'
  FROM ind
 WHERE index_type = 'DOMAIN' AND ityp_name = 'CHM';

quit;
