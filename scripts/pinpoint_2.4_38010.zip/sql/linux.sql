delete options;

insert into options(name, value)
  values('license',
         '244b48928b74b83fe63307ce7aa1bd4da9f5a89d9df0a9eb');

quit;
