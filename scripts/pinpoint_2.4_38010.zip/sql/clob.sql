create or replace FUNCTION acc_mol2smi(smiles IN cLOB)
		return varchar2 is external
           	NAME "acc_mol2smi"
           	LIBRARY astex
		with context
           	PARAMETERS (CONTEXT,
                 smiles  OCILOBLOCATOR,
                 smiles  INDICATOR short,
                 return INDICATOR short,
               	return LENGTH short);
/
show errors

quit;
