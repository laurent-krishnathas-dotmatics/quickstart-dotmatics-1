drop table maybridge_idx_chm;
drop index m_idx force;
drop index chemaxon_smiles_idx force;
drop index corporate_smiles_idx force;
drop index it1;
drop table t1;
drop indextype chm;
drop type chm_im;
drop operator acc_contains;
drop operator acc_exact;
drop operator acc_fp;
drop operator acc_sim;
drop function acc_containsf;
drop function acc_exactf;
drop function acc_fpf;
drop function acc_simf;

quit;

