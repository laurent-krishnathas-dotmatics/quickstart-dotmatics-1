create or replace library dotmatics_lib as
--'/usr/lib/oracle/xe/app/oracle/product/10.2.0/server/lib/libpinpoint_linux.so';
'C:\oraclexe\app\oracle\product\10.2.0\server\BIN\acc_cartridge.dll';

/

show errors;

--quit;
