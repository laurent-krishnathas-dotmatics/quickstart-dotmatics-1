
set echo off

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_cansmi(s IN varchar2)
		return varchar2 deterministic is external
           	NAME "acc_cansmi"
           	LIBRARY dotmatics_lib
           	WITH CONTEXT
   			PARAMETERS(CONTEXT, s string,
   			    s  INDICATOR short,
   			    return INDICATOR short,
               	return LENGTH short);
/
show errors


-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_cansmi_noniso(s IN varchar2)
		return varchar2 deterministic is external
           	NAME "acc_cansmi_noniso"
           	LIBRARY dotmatics_lib
           	WITH CONTEXT
   			PARAMETERS(CONTEXT, s string,
   			    s  INDICATOR short,
   			    return INDICATOR short,
               	return LENGTH short);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_get_version
		return varchar2 deterministic is external
           	NAME "acc_get_version"
           	LIBRARY dotmatics_lib;
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace PROCEDURE acc_set_log_level(level IN binary_integer)
		is external
           	NAME "acc_set_log_level"
           	LIBRARY dotmatics_lib
           	PARAMETERS (level int);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_calc_mw(smiles IN varchar2)
		return float is external
           	NAME "acc_calc_mw"
           	LIBRARY dotmatics_lib
           	PARAMETERS (smiles string,
           	   	smiles  INDICATOR short);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_inchi2mw(smiles IN varchar2)
		return float is external
           	NAME "acc_inchi2mw"
           	LIBRARY dotmatics_lib
           	PARAMETERS (smiles string,
           	    smiles  INDICATOR short);
/
show errors

create or replace FUNCTION acc_formula2mw(smiles IN varchar2)
		return float is external
           	NAME "acc_formula2mw"
           	LIBRARY dotmatics_lib
           	PARAMETERS (smiles string,
           	    smiles  INDICATOR short);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_calc_hac(smiles IN varchar2)
		return binary_integer is external
           	NAME "acc_calc_hac"
           	LIBRARY dotmatics_lib
           	PARAMETERS (smiles string,
           	    smiles  INDICATOR short);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_calc_mw_exact(smiles IN varchar2)
        return float is external
            NAME "acc_calc_mw_exact"
            LIBRARY dotmatics_lib
            PARAMETERS (smiles string,
                smiles  INDICATOR short);
/
show errors

grant execute on acc_set_log_level to pinpoint;
grant execute on acc_set_log_level to public;

grant execute on acc_cansmi to pinpoint;
grant execute on acc_cansmi to public;

grant execute on acc_cansmi_noniso to pinpoint;
grant execute on acc_cansmi_noniso to public;

grant execute on acc_get_version to pinpoint;
grant execute on acc_get_version to public;

grant execute on acc_calc_mw_exact to pinpoint;
grant execute on acc_calc_mw_exact to public;

create public synonym acc_cansmi for acc_cansmi;
create public synonym acc_cansmi_noniso for acc_cansmi_noniso;
create public synonym acc_get_version for acc_get_version;
create public synonym acc_set_log_level for acc_set_log_level;
create public synonym acc_calc_mw_exact for acc_calc_mw_exact;


--quit;
