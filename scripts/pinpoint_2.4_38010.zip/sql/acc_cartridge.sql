-- Implementation of chemistry searching cartridge and associated functions


--connect extdemo2/extdemo2
connect mikeh/mikeh
set echo off
--@'?/rdbms/admin/utlxplan.sql'
set echo on

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_mol2smi(smiles IN BLOB)
		return varchar2 is external
           	NAME "acc_mol2smi"
           	LIBRARY astex
		with context
           	PARAMETERS (CONTEXT,
                 smiles  OCILOBLOCATOR,
                 smiles  INDICATOR short,
                 return INDICATOR short,
               	return LENGTH short);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_calc_mw(smiles IN varchar2)
		return float is external
           	NAME "acc_calc_mw"
           	LIBRARY astex
           	PARAMETERS (smiles string);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_compare(fp1 IN varchar2, fp2 IN varchar2, method IN varchar2)
		return float is external
           	NAME "acc_compare"
           	LIBRARY astex
           	PARAMETERS (fp1 string, fp2 string, method string);
/
show errors

-- CREATE FUNCTIONAL IMPLEMENTATIONS for operators
create or replace FUNCTION acc_calc_hac(smiles IN varchar2)
		return binary_integer is external
           	NAME "acc_calc_hac"
           	LIBRARY astex
           	PARAMETERS (smiles string);
/
show errors

create or replace function acc_contains2(a varchar2, b varchar2) return binary_integer as
   EXTERNAL
   LANGUAGE C
   NAME "acc_contains2"
   LIBRARY astex
   PARAMETERS(a string, b string);
/
show errors

create or replace function acc_containsf(a varchar2, b varchar2) return number as
   EXTERNAL
   LANGUAGE C
   NAME "acc_contains"
   LIBRARY astex
   WITH CONTEXT
   PARAMETERS(CONTEXT, a string, a indicator, b string, b indicator);
/
show errors

create or replace function acc_exactf(a varchar2, b varchar2) return number as
   EXTERNAL
   LANGUAGE C
   NAME "acc_exact"
   LIBRARY astex
   WITH CONTEXT
   PARAMETERS(CONTEXT, a string, a indicator, b string, b indicator);
/
show errors

create function acc_fpf(a varchar2, b varchar2) return number as
begin
  if a > b then
    return 1;
  else
    return 0;
  end if;
end;
/
show errors

create function acc_simf(a varchar2, b varchar2) return number as
begin
  if a > b then
    return 1;
  else
    return 0;
  end if;
end;
/
show errors

-- CREATE BTREE OPERATORS

create operator acc_contains binding (varchar2, varchar2) return number using acc_containsf;

create operator acc_exact binding (varchar2, varchar2) return number using acc_exactf;

create operator acc_fp binding (varchar2, varchar2) return number using acc_fpf;

create operator acc_sim binding (varchar2, varchar2) return number using acc_simf;


-- CREATE INDEXTYPE IMPLEMENTATION TYPE
create type chm_im as object
(
  scanctx RAW(4),
  static function ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList)
  return NUMBER,
  static function ODCIIndexCreate (ia sys.odciindexinfo, parms varchar2)
  return number,
  static function ODCIIndexDrop(ia sys.odciindexinfo) return number,
  STATIC FUNCTION odciindexinsert(ia sys.odciindexinfo, rid VARCHAR2,
                                                    newval VARCHAR2)
                                  RETURN NUMBER,
  STATIC FUNCTION odciindexdelete(ia sys.odciindexinfo, rid VARCHAR2,
                                                    oldval VARCHAR2)
                                  RETURN NUMBER,
  STATIC FUNCTION odciindexupdate(ia sys.odciindexinfo, rid VARCHAR2,
                                  oldval VARCHAR2, newval VARCHAR2)
                                  RETURN NUMBER,
  static function ODCIIndexStart(sctx IN OUT chm_im, ia sys.odciindexinfo,
                         op sys.odciPredInfo, qi sys.ODCIQueryInfo,
                         strt number, stop number,
                         cmpval varchar2) return number,
  member function ODCIIndexFetch(nrows number, rids OUT sys.odciridlist)
      return number,
  member function ODCIIndexClose return number
);
/
show errors


---------------------------------
--  CREATE IMPLEMENTATION UNIT --
---------------------------------

-- CREATE TYPE BODY
create or replace type body chm_im
is
   static function ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList)
       return number is
   begin
       ifclist := sys.ODCIObjectList(sys.ODCIObject('SYS','ODCIINDEX1'));
       return ODCIConst.Success;
   end ODCIGetInterfaces;

--  static function ODCIIndexCreate (ia sys.odciindexinfo, parms varchar2)
--   return number
--  is
--   i integer;
--   stmt varchar2(1000);
--   cnum integer;
--   junk integer;
--  begin
--   -- construct the sql statement
--     stmt := 'create table ' || ia.IndexSchema || '.' ||
--       ia.IndexName || '_chm'  ||
--       '( f1 , f2 ) as select ' ||
--       ia.IndexCols(1).ColName || ', ROWID from ' ||
--      ia.IndexCols(1).TableSchema || '.' || ia.IndexCols(1).TableName;
--
--   dbms_output.put_line('CREATE');
--   dbms_output.put_line(stmt);
--
--   -- execute the statement
--   cnum := dbms_sql.open_cursor;
--   dbms_sql.parse(cnum, stmt, dbms_sql.native);
--   junk := dbms_sql.execute(cnum);
--   dbms_sql.close_cursor(cnum);
--
--   return ODCIConst.Success;
--  end;

  static function ODCIIndexDrop(ia sys.odciindexinfo) return number is
   stmt varchar2(1000);
   cnum integer;
   junk integer;
  begin
    -- construct the sql statement
   stmt := 'drop table ' || ia.IndexSchema || '.' || ia.IndexName || '_chm';

   dbms_output.put_line('DROP');
   dbms_output.put_line(stmt);

   -- execute the statement
   cnum := dbms_sql.open_cursor;
   dbms_sql.parse(cnum, stmt, dbms_sql.native);
   junk := dbms_sql.execute(cnum);
   dbms_sql.close_cursor(cnum);

   return ODCIConst.Success;
  end;

  STATIC FUNCTION odciindexcreate(ia sys.odciindexinfo, parms VARCHAR2)
                                  RETURN NUMBER AS external
    name "qxiqtbz"
    library astex
    WITH context
    parameters (
    context,
    ia,
    ia indicator struct,
	parms,
	parms indicator,
    RETURN ocinumber
               );

  STATIC FUNCTION odciindexinsert(ia sys.odciindexinfo, rid VARCHAR2,
                                                    newval VARCHAR2)
                                  RETURN NUMBER AS external
    name "qxiqtbi"
    library astex
    WITH context
    parameters (
    context,
    ia,
    ia indicator struct,
    rid,
    rid indicator,
    newval,
    newval indicator,
    RETURN ocinumber
               );

  STATIC FUNCTION odciindexdelete(ia sys.odciindexinfo, rid VARCHAR2,
                                                    oldval VARCHAR2)
                                  RETURN NUMBER AS external
    name "qxiqtbd"
    library astex
    WITH context
    parameters (
    context,
    ia,
    ia indicator struct,
    rid,
    rid indicator,
    oldval,
    oldval indicator,
    RETURN ocinumber
               );

  STATIC FUNCTION odciindexupdate(ia sys.odciindexinfo, rid VARCHAR2,
                                  oldval VARCHAR2, newval VARCHAR2)
                                  RETURN NUMBER AS external
    name "qxiqtbu"
    library astex
    WITH context
    parameters (
    context,
    ia,
    ia indicator struct,
    rid,
    rid indicator,
    oldval,
    oldval indicator,
    newval,
    newval indicator,
    RETURN ocinumber
               );

  static function ODCIIndexStart(sctx in out chm_im, ia sys.odciindexinfo,
                         op sys.odciPredInfo,
                         qi sys.ODCIQueryInfo,
                         strt number,
                         stop number,
                         cmpval varchar2)
     return number as external
     name "qxiqtbs"
     library astex
     with context
     parameters (
       context,
       sctx,
       sctx INDICATOR STRUCT,
       ia,
       ia INDICATOR STRUCT,
       op,
       op INDICATOR STRUCT,
       qi,
       qi INDICATOR STRUCT,
       strt,
       strt INDICATOR,
       stop,
       stop INDICATOR,
       cmpval,
       cmpval INDICATOR,
       return OCINumber
    );

  member function ODCIIndexFetch(nrows number, rids OUT sys.odciridlist)
   return number as external
   name "qxiqtbf"
   library astex
   with context
   parameters (
     context,
     self,
     self INDICATOR STRUCT,
     nrows,
     nrows INDICATOR,
     rids,
     rids INDICATOR,
     return OCINumber
   );

  member function ODCIIndexClose return number as external
   name "qxiqtbc"
   library astex
   with context
   parameters (
     context,
     self,
     self INDICATOR STRUCT,
     return OCINumber
   );

end;
/
show errors

---------------------
-- CREATE INDEXTYPE
---------------------

create indextype chm
for
acc_contains(varchar2, varchar2),
acc_exact(varchar2, varchar2),
acc_fp(varchar2, varchar2),
acc_sim(varchar2, varchar2)
using chm_im;

---------------------
-- CREATE LICENSE TABLE
---------------------

-- create table options (
--name varchar2(1000),
--value varchar2(1000)
--);

--insert into options(name, value) values('license', '03079d161d5934005f1b822d28291561af38728a75a60192');

--------------------------
--    USAGE EXAMPLES    --
--------------------------
set serveroutput on size 20000

-----------------
-- CREATE INDEX
-----------------

set timing on;

create table test (
smiles varchar2(4000),
id integer
);

insert into test(smiles, id) values('c1ccccc1', 1);
insert into test(smiles, id) values('c1ncccc1', 2);
insert into test(smiles, id) values('c1ncccc1Cl', 3);
insert into test(smiles, id) values('c1ncccc1Br', 4);

create index test_idx on test(smiles) indextype is chm parameters('test');

select count(*) from test where acc_contains(smiles, 'c1ncccc1') = 1;

select count(*) from test where acc_contains(smiles, 'Cl') = 1;

select count(*) from test where acc_contains(smiles, '[Cl,Br]') = 1;

drop index test_idx;

drop table test;

------------
-- QUERIES
------------

------------
-- CLEANUPS
------------

--drop table maybridge_idx_chm;

--drop index it1;
--drop table t1;
--drop indextype chm;
--drop type chm_im;
--drop operator acc_contains;
--drop operator acc_exact;
--drop operator acc_fp;
--drop operator acc_sim;
--drop function acc_containsf;
--drop function acc_exactf;
--drop function acc_simf;

quit;
