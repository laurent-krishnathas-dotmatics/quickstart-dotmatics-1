-- Create cartridge owner
-- This script needs to be run by an account with
-- dba privileges

create user c$pinpoint identified by pinpoint
	default tablespace users
    temporary tablespace temp
    profile default;

grant resource to c$pinpoint;
grant connect to c$pinpoint;
grant create operator to c$pinpoint;
grant create indextype to c$pinpoint;
grant create library to c$pinpoint;
grant create procedure to c$pinpoint;
grant create role to c$pinpoint;
grant create type to c$pinpoint;
grant create public synonym to c$pinpoint;

grant create table to c$pinpoint with admin option;

grant create view to c$pinpoint;

grant create any directory to c$pinpoint;

grant drop public synonym to c$pinpoint;

grant unlimited tablespace to c$pinpoint;

--quit;


