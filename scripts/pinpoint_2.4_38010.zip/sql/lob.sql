CREATE OR REPLACE FUNCTION process_clob
  ( process_str IN varchar2,
    lob_in IN CLOB
  ) RETURN CLOB
IS EXTERNAL
NAME "process_lob"
LIBRARY dotmatics_lib
WITH CONTEXT
PARAMETERS
(
  context,
  process_str string,
  lob_in ociloblocator,
  process_str INDICATOR SB4,
  lob_in    INDICATOR SB4,
  RETURN    INDICATOR SB4
);
/
show errors;


CREATE OR REPLACE FUNCTION process_blob
  ( process_str IN varchar2,
    lob_in IN BLOB
  ) RETURN BLOB
IS EXTERNAL
NAME "process_lob"
LIBRARY dotmatics_lib
WITH CONTEXT
PARAMETERS
(
  context,
  process_str string,
  lob_in ociloblocator,
  process_str INDICATOR SB4,
  lob_in    INDICATOR SB4,
  RETURN    INDICATOR SB4
);
/
show errors;

quit;
